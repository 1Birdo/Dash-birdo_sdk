__version__ = "1.0.0"
__author__ = "Birdo Team"
__license__ = "MIT"
__description__ = "Official Python SDK for Birdo Monitoring Service"